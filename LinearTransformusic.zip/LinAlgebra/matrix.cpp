#include "matrix.h"

// Arquivo vazio. Havia conflito com o uso dos Templates, e a funçao de 
// multiplicaçao de matrizes teve seu codigo movido para matrix.h