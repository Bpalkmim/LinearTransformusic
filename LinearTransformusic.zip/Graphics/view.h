#ifndef VIEW_H
#define VIEW_H

// Menu principal da aplicaçao, em linha de comando
void showMenu(void);


#endif