#include "Graphics/view.h"

int main(int argc, char *argv[]) 
{
	showMenu();
	return 0;
}